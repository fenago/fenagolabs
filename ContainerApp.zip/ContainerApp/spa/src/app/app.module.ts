import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { TabsModule } from 'ngx-bootstrap/tabs';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './home/header/header.component';
import { ProductComponent } from './home/product/product.component';
import { CoursesComponent } from './home/courses/courses.component';
import { LanguageComponent } from './home/language/language.component';
import { ReasonComponent } from './home/reason/reason.component';
import { SayingComponent } from './home/saying/saying.component';
import { FooterComponent } from './home/footer/footer.component';
import { MainComponent } from './home/main/main.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { ProductPageComponent } from './product-page/product-page.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { RegisterPageComponent } from './register-page/register-page.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { KeepHtmlPipe } from './pipes/keep-html.pipe';

@NgModule({
   declarations: [
      AppComponent,
      HeaderComponent,
      ProductComponent,
      CoursesComponent,
      LanguageComponent,
      ReasonComponent,
      SayingComponent,
      FooterComponent,
      MainComponent,
      CheckoutComponent,
      ProductPageComponent,
      LoginPageComponent,
      RegisterPageComponent,
      KeepHtmlPipe
   ],
   imports: [
      BrowserModule,
      AppRoutingModule,
      BrowserAnimationsModule,
      TabsModule.forRoot()
   ],
   providers: [],
   bootstrap: [
      AppComponent
   ]
})
export class AppModule { }
