import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-page',
  templateUrl: './product-page.component.html',
  styleUrls: ['./product-page.component.css']
})
export class ProductPageComponent implements OnInit {
  command: string;
  constructor() { }

  ngOnInit() {
    this.command = `export TOKEN=$(kubectl describe secret $(kubectl 
                    get secret | awk '/^dashboard-token-/{print $1}')
                    | awk '$1=="token:"{print $2}') &amp;&amp;
                    echo -e "\n--- Copy and paste this token for 
                    dashboard access --\n$TOKEN\n---"`;
  }

}
