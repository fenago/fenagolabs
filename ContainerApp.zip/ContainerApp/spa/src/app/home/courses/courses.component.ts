import { Component, OnInit } from '@angular/core';
import { Product } from '../../models/product';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {
  courses: Product[] = [];
  constructor() { }

  ngOnInit() {
    for (let i = 0; i < 9; i++) {
      this.courses.push({
        id: 0,
        photoUrl: '',
        title: 'Kubernetes Introduction',
        description: 'Get started using Kubernetes'
      });
    }
  }

}
