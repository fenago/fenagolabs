import { Component, OnInit } from '@angular/core';
import { Product } from '../../models/product';

@Component({
  selector: 'app-language',
  templateUrl: './language.component.html',
  styleUrls: ['./language.component.css']
})
export class LanguageComponent implements OnInit {
  languages: Product[] = [];
  constructor() { }

  ngOnInit() {
    for (let i = 0; i < 6; i++) {
      this.languages.push({
        id: 0,
        photoUrl: '',
        title: 'Running .NET in Docker',
        description: 'Learn how to run .NET inside Docker Containers'
      });
    }
  }

}
