import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saying',
  templateUrl: './saying.component.html',
  styleUrls: ['./saying.component.css']
})
export class SayingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
