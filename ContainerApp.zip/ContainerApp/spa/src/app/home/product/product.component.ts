import { Component, OnInit } from '@angular/core';
import { Product } from '../../models/product';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  products: Product[];

  constructor() { }

  ngOnInit() {
    this.products = [
      {
        id: 1,
        title: 'Learn & Discover the latest technologies and tooling',
        description: 'Empowering developers to learn the technologies such as Kubernetes',
        photoUrl: 'https://katacoda.com/images/icons/code.jpg'
      },
      {
        id: 2,
        title: 'Learn & Discover the latest technologies and tooling',
        description: 'Empowering developers to learn the technologies such as Kubernetes',
        photoUrl: 'https://katacoda.com/images/icons/configure.jpg'
      },
      {
        id: 3,
        title: 'Learn & Discover the latest technologies and tooling',
        description: 'Empowering developers to learn the technologies such as Kubernetes',
        photoUrl: 'https://katacoda.com/images/icons/do.png'
      },
      {
        id: 4,
        title: 'Learn & Discover the latest technologies and tooling',
        description: 'Empowering developers to learn the technologies such as Kubernetes',
        photoUrl: 'https://katacoda.com/images/icons/guided.png'
      },
    ];
  }

}
