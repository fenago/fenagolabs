/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { KeepHtmlPipe } from './keep-html.pipe';

describe('Pipe: KeepHtmle', () => {
  it('create an instance', () => {
    let pipe = new KeepHtmlPipe();
    expect(pipe).toBeTruthy();
  });
});
